# Q1 -> Lire le fichier shapefile "coteivoire_gaul_adm1_geo.shp" sous une variable nommee "mon_vecteur" 
mon_vecteur <- readOGR(dsn="data/vector/",
                      layer="coteivoire_gaul_adm1_geo")
# Q2 -> Afficher le shapefile  et faire ressortir Abidjan en rouge

plot(mon_vecteur)
table(mon_vecteur$ADM1_NAME)
plot(mon_vecteur[mon_vecteur$ADM1_NAME=="District autonome de Abidjan",],add=T,col="red")
# Q3 -> Reprojeter les vecteur en UTM zone 30 (mon_utm)
mon_utm <-spTransform(mon_vecteur,CRS("+init=epsg:32730"))
# Q4 -> Calculer les surfaces des polygones dans une colonne appelee superficie (fonction gArea)
mon_utm$superficie <- gArea(mon_utm,byid=T)
# Q5 -> Afficher la table des attributs
mon_utm@data
# Q6 -> Lire le fichier shapefile "mes_points.kml" sous une variable nommee "mes_points" 
mes_points <- readOGR(dsn="data/vector/mes_points.kml",layer="mes_points")
# Q7  -> projeter mes_points en UTM
mes_points <- spTransform(mes_points, CRS("+init=epsg:32730"))

# Q8 -> Extraire les points qui tombent sur le departement d'Abidjan
pts_abidjan <- mes_points[
  mon_utm[mon_utm$ADM1_NAME=="District autonome de Abidjan",],]

# Q9 -> Creer un Shapefile Abidjan et Yamossoukro
union <- gUnion(mon_utm[
  mon_utm$ADM1_NAME=="District autonome de Abidjan",],
  mon_utm[mon_utm$ADM1_NAME=="District autonome de Yamoussoukro",])

# Afficher l'union des deux departements en bleu sur la carte
plot(union,add=T,col="blue")
