# Q1 -> Lire les fichiers : 
# "congo_departement_geo.shp" sous une variable nommee  "DPT"
# "gfc_tc_agg.tif"            sous une variable nommee  "GFC"
# "points_aleatoires.csv"     sous un variable nommee   "PTS"

DPT <- readOGR(dsn="data/vector/",layer="coteivoire_gaul_adm1_geo")
GFC <- raster("data/raster/gfc_tc_agg.tif")
PTS <- read.csv("data/table/points_aleatoires.csv")

# Q2 -> Creer un nouveau raster appele "tc_class" des classes de couverture arboree 
# classe 1 : TC 0-30  
# classe 2 : TC 30-70 
# classe 3 : TC 70-100
tc_class <- (GFC<30) + (GFC>=30 & GFC < 70)*2 + (GFC > 70)*3

# Q3 -> Visualiser le nouveau raster
plot(tc_class)

# Q3 -> Extraire la valeur de couverture arboree pour chaque point 
### l'inserer comme nouvelle colonne ("couverture") dans le fichier table
PTS$couverture <- extract(GFC,PTS[,c(1:2)])

# Q4 -> Chercher la documentation de la fonction boxplot
?boxplot

# Q5 -> Afficher pour PTS les moyennes et quantiles de couverture arboree par classe de couverture
graphics::boxplot(PTS$couverture ~ PTS$value)

# Q6 -> Creer la liste des valeurs uniques de value dans PTS (appelez la ma_liste)
ma_liste <- levels(as.factor(PTS$value))

# Q7 -> Creer une fonction qui affiche le nombre de ligne du fichier PTS pour une "value" donnee
comptage <- function(x){nrow(PTS[PTS$value==x,])}

# Q8 -> Appliquer la fonction a ma_liste. Quelle est la fonction globale que vous avez recree ?
sapply(ma_liste,comptage)
table(PTS$value)


# Q9 -> Creer un raster des departements du pays @ la meme resolution que GFC
tmp<-raster(resolution=res(GFC),ext=extent(GFC),crs=projection(GFC))
dpt_rast <- rasterize(x=DPT,y=tmp,field="ADM1_CODE",background=0,fun='first',update=T)
plot(dpt_rast)


# Q10 -> Chercher la fonction "zonal" et Calculer la moyenne, le min et le max de couverture arboree par departement
x1 <- zonal(GFC,dpt_rast,fun='mean')
x2 <- zonal(GFC,dpt_rast,fun='max')
x3 <- zonal(GFC,dpt_rast,fun='min')
gfc_dpt <- merge(x1,x2)
gfc_dpt <- merge(gfc_dpt,x3)
(gfc_dpt <- merge(DPT@data[,c(3,4)],gfc_dpt,by.x=1,by.y=1))
