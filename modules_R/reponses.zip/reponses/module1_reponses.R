### Q1  -> Lire la table classes.csv, sous le nom de variable df
df <- read.csv("data/table/classes.csv")
### Q2  -> Afficher le nom des colonnes de df
names(df)
### Q3  -> Afficher le type d'objet de df
str(df)
### Q4  -> Ajouter une colonne test ou toutes les valeurs sont egales a "neutre"
df$test <- "neutre"
### Q5  -> Changer la valeur de test tel que la valeur soit "positif" si "code_1990" et "code_2000" sont egaux
df[df$code_1990 ==  df$code_2000 ,]$test <- "positif"
### Q6  -> Afficher la table des valeurs de la colonne test
table(df$testtable(df$code_2015,df$code_2000)
### Q7  -> Creer une copie de df appelee my_df
my_df <- df
### Q8  -> Extraire la dixieme ligne de my_df (ma_ligne)
ma_ligne <- my_df[10,]
### Q9  -> ajouter ma_ligne a la fin de my_df (fonction rbind)
my_df <- rbind(my_df,ma_ligne)
### Q10 -> Repeter 10 fois l' alphabet (fonction letters)
rep(letters,10)
