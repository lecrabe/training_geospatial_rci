# Q1  -> Lire le fichier raster CCI sous une variable nommee "mon_raster" 
mon_raster <- raster("data//raster//cci_rci.tif")

# Q2  -> Extraire un sous-raster spatial pour la zone 5 a 7 degres Ouest et 4 a 5 degres Nord, nommer le "sub_raster"
sub_raster <- crop(mon_raster,extent(-7,-5,4,5))

# Q3  -> Generer une grille de 500 points sur "sub_raster" appelee "ma_grille" (NB: conserver les coordonnees)
#        nb: faire en sorte que la grille soit sous format data.frame
ma_grille <- data.frame(sampleRandom(sub_raster,500,xy=TRUE))

# Q4  -> Renommer les colonnes de "ma_grille" avec les valeurs "x_coord", "y_coord" et "value". Ajouter une colonne avec un identifiant "id" unique
names(ma_grille) <- c("x_coord", "y_coord","value")

# Q5  -> Afficher la distribution des points pour chaque classe
table(ma_grille$value)

# Q6  -> Creer un identifiant unique dans ma_grille
ma_grille$id <-row(ma_grille)[,1]

# Q7  -> Extraire l'identifiant de 10 points aleatoires parmi ma_grille ayant la classe "210"
tmp <- sample(ma_grille[ma_grille$value==210,]$id,10)

# Q8  -> Extraire une sous-grille cl210 correspondant a ces identifiants
cl210 <- ma_grille[tmp,]

# Q9  -> Creer un graphique vide de la taille de "sub_raster", avec les labels "longitude" en abscisse et "latitude" en ordonnee
plot(ma_grille$x_coord,ma_grille$y_coord,type="n",xlab="longitude",ylab="latitude")

# Q10 -> Afficher "sub_raster" en fond de graphe, les points de ma_grille (en noir), les points cl210 en bleu
plot(sub_raster,add=T)
points(ma_grille$x_coord,ma_grille$y_coord)
points(cl210$x_coord,cl210$y_coord,col="blue")
